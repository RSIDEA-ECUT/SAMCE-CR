import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from einops import rearrange
from torch.autograd import Function
from torch.nn.modules.utils import _pair
import numbers


                                                                          
             

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


                                                                          
          
class DeformConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1, dilation=1, groups=1):
        super(DeformConv2d, self).__init__()
        self.kernel_size = _pair(kernel_size)
        self.stride = _pair(stride)
        self.padding = _pair(padding)
        self.dilation = _pair(dilation)
        self.groups = groups

        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels // groups, *self.kernel_size))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

    def forward(self, x, offset):
        return deform_conv2d(x, offset, self.weight, self.stride, self.padding, self.dilation, self.groups)


def deform_conv2d(input, offset, weight, stride=1, padding=0, dilation=1, groups=1):
    N, inC, inH, inW = input.size()
    outC, _, kH, kW = weight.size()
    stride = _pair(stride)
    padding = _pair(padding)
    dilation = _pair(dilation)
    outH = (inH + 2 * padding[0] - dilation[0] * (kH - 1) - 1) // stride[0] + 1
    outW = (inW + 2 * padding[1] - dilation[1] * (kW - 1) - 1) // stride[1] + 1

    grid = _generate_grid(offset, (inH, inW), stride, padding, dilation, kH, kW)

    K = kH * kW
    input_flat = input.repeat_interleave(K, dim=0)
    grid_flat = grid.reshape(N * K, outH, outW, 2)
    sampled = F.grid_sample(input_flat, grid_flat, align_corners=True)
    sampled = sampled.reshape(N, K, inC, outH, outW).permute(0, 2, 1, 3, 4)
    w = weight.reshape(outC, inC, K)
    out = torch.einsum('oik,bikhw->bohw', w, sampled)

    return out


def _generate_grid(offset, input_size, stride, padding, dilation, kH, kW):
    N, _, outH, outW = offset.size()
    inH, inW = input_size
    sy, sx = stride
    py, px = padding
    dy, dx = dilation
    y, x = torch.meshgrid(torch.arange(outH), torch.arange(outW), indexing='ij')
    base = torch.stack([x, y], dim=-1).float().to(offset.device)
    base[..., 0] = base[..., 0] * sx - px
    base[..., 1] = base[..., 1] * sy - py
    base = base.unsqueeze(0).repeat(N, 1, 1, 1)
    ky, kx = torch.meshgrid(torch.arange(kH), torch.arange(kW), indexing='ij')
    kernel = torch.stack([kx, ky], dim=-1).float().to(offset.device).reshape(1, 1, 1, kH * kW, 2)
    kernel[..., 0] = kernel[..., 0] * dx
    kernel[..., 1] = kernel[..., 1] * dy
    grid = base.unsqueeze(3) + kernel
    offset = offset.permute(0, 2, 3, 1).reshape(N, outH, outW, kH * kW, 2)
    grid = grid + offset

    grid[..., 0] = 2.0 * grid[..., 0] / (inW - 1) - 1.0
    grid[..., 1] = 2.0 * grid[..., 1] / (inH - 1) - 1.0

    return grid


class DeformableAlign(nn.Module):
    def __init__(self, sar_channels=2, ref_channels=13, groups=8):
        super().__init__()
              
        self.conv_l1_src = nn.Conv2d(sar_channels, sar_channels, 3, padding=1)
        self.conv_l1_ref = nn.Conv2d(ref_channels, ref_channels, 3, padding=1)

               
        self.offset_conv = nn.Sequential(
            nn.Conv2d(sar_channels + ref_channels, sar_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(sar_channels, 2 * 3 * 3, 3, padding=1)                    
        )

               
        self.deform_conv = DeformConv2d(sar_channels, sar_channels)

        self.post_conv = nn.Conv2d(sar_channels, sar_channels, 3, padding=1)

        self.act = nn.PReLU()

    def forward(self, src, ref):
              
        src_feat = self.act(self.conv_l1_src(src))
        ref_feat = self.act(self.conv_l1_ref(ref))

               
        offset = self.offset_conv(torch.cat([src_feat, ref_feat], dim=1))

                 
        aligned = self.deform_conv(src_feat, offset)
        aligned = self.post_conv(aligned)
        return aligned


                                                                          
                                          
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3, stride=1, padding=1,
                                groups=hidden_features * 2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x


                                                                          
                                                    
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape

        qkv = self.qkv_dwconv(self.qkv(x))
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)

        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out


                                                                          
                   
class Downsample(nn.Module):
    def __init__(self, n_feat):
        super(Downsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat // 2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelUnshuffle(2))

    def forward(self, x):
        return self.body(x)


class Upsample(nn.Module):
    def __init__(self, n_feat):
        super(Upsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat * 2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelShuffle(2))

    def forward(self, x):
        return self.body(x)


                                                                          
                    
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(TransformerBlock, self).__init__()

        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        return x


                                                                          
            
class ImprovedChannelAttention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(ImprovedChannelAttention, self).__init__()

               
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1, bias=bias),
            nn.PReLU(),
            nn.Conv2d(dim // 4, dim, 1, bias=bias),
            nn.Sigmoid()
        )

               
        self.cross_attention = nn.MultiheadAttention(dim, num_heads, bias=bias)

              
        self.fusion = nn.Sequential(
            nn.Conv2d(dim * 2, dim, 1, bias=bias),
            nn.PReLU(),
            nn.Conv2d(dim, dim, 3, padding=1, bias=bias),
            nn.PReLU()
        )

    def forward(self, x, y):
               
        ca = self.channel_attention(x)
        x_ca = x * ca

               
        b, c, h, w = x.shape
        x_flat = x.view(b, c, -1).permute(2, 0, 1)               
        y_flat = y.view(b, c, -1).permute(2, 0, 1)               

        attn_output, _ = self.cross_attention(x_flat, y_flat, y_flat)
        x_cross = attn_output.permute(1, 2, 0).view(b, c, h, w)

              
        out = self.fusion(torch.cat([x_ca, x_cross], dim=1))
        return out + x        


class EnhancedFrequencyModule(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(EnhancedFrequencyModule, self).__init__()

                   
        self.freq_split = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, 1, 1, bias=bias),                         
            nn.Sigmoid()
        )

                    
        self.high_attn = nn.ModuleList([ImprovedChannelAttention(dim, num_heads, bias) for _ in range(2)])
        self.low_attn = nn.ModuleList([ImprovedChannelAttention(dim, num_heads, bias) for _ in range(2)])

                
        self.fusion = nn.Sequential(
            nn.Conv2d(dim * 4, dim, 1, bias=bias),
            nn.PReLU(),
            nn.Conv2d(dim, dim, 3, padding=1, bias=bias),
            nn.PReLU()
        )

                 
        self.residual = nn.Sequential(
            nn.Conv2d(dim, dim, 3, padding=1, bias=bias),
            nn.PReLU(),
            nn.Conv2d(dim, 1, 1, bias=bias),
            nn.Sigmoid()
        )

                  
        self.gamma = nn.Parameter(torch.ones(1))

                
        self.freq_enhance = nn.Sequential(
            nn.Conv2d(dim, dim, 3, padding=1, bias=bias),
            nn.PReLU(),
            nn.Conv2d(dim, dim, 3, padding=1, bias=bias),
            nn.PReLU()
        )

    def forward(self, x, y):
        B, C, H, W = x.shape

                
        tau = self.freq_split(x) * 0.5

                
        high_mask, low_mask = self._generate_masks(H, W, tau, x.device)

               
        fft_feat = torch.fft.rfft2(x, norm='ortho')

              
        fft_feat = self.freq_enhance(fft_feat.real) + 1j * self.freq_enhance(fft_feat.imag)

              
        high_freq = fft_feat * high_mask
        high_feat = torch.fft.irfft2(high_freq, s=(H, W), norm='ortho')
        high_outs = [attn(high_feat, y) for attn in self.high_attn]

              
        low_freq = fft_feat * low_mask
        low_feat = torch.fft.irfft2(low_freq, s=(H, W), norm='ortho')
        low_outs = [attn(low_feat, y) for attn in self.low_attn]

              
        all_features = torch.cat(high_outs + low_outs, dim=1)
        fused = self.fusion(all_features)

               
        alpha = self.residual(fused)
        return y + self.gamma * alpha * fused

    def _generate_masks(self, H, W, tau, device):
                  
        h_coords = torch.linspace(-0.5, 0.5, H, device=device)
        w_coords = torch.linspace(-0.5, 0.5, W // 2 + 1, device=device)            
        h_grid, w_grid = torch.meshgrid(h_coords, w_coords, indexing='ij')                

                
        freq_radius = torch.sqrt(h_grid ** 2 + w_grid ** 2)
        freq_radius = freq_radius.unsqueeze(0).unsqueeze(0)                  

                
        high_mask = (freq_radius > tau).float()
        low_mask = (freq_radius <= tau).float()

        return high_mask, low_mask                   


                                                                          
            
class BasicBlock(nn.Sequential):
    def __init__(self, conv, in_channels, out_channels, kernel_size, stride=1, bias=True, bn=False, act=nn.PReLU()):
        m = [conv(in_channels, out_channels, kernel_size, bias=bias)]
        if bn:
            m.append(nn.BatchNorm2d(out_channels))
        if act is not None:
            m.append(act)
        super(BasicBlock, self).__init__(*m)


def default_conv(in_channels, out_channels, kernel_size, stride=1, bias=True):
    return nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size // 2), stride=stride, bias=bias)


class SAR_SuperResolution(nn.Module):
                                         

    def __init__(self, in_channels=1, out_channels=2, upscale_factor=2, feature_channels=64):
        super().__init__()
        self.upscale_factor = upscale_factor

                 
        self.conv1 = BasicBlock(default_conv, in_channels, feature_channels, 9, act=nn.PReLU())
        self.conv2 = BasicBlock(default_conv, in_channels, feature_channels, 5, act=nn.PReLU())
        self.conv3 = BasicBlock(default_conv, in_channels, feature_channels, 3, act=nn.PReLU())

              
        self.fusion = nn.Sequential(
            nn.Conv2d(feature_channels * 3, feature_channels, 1),
            nn.PReLU()
        )

                  
        self.attention = nn.Sequential(
            nn.Conv2d(feature_channels, feature_channels, 1),
            nn.PReLU(),
            nn.Conv2d(feature_channels, feature_channels, 3, padding=1),
            nn.PReLU(),
            nn.Conv2d(feature_channels, feature_channels, 1),
            nn.Sigmoid()
        )

               
        self.up = nn.Sequential(
            nn.Conv2d(feature_channels, feature_channels * (upscale_factor ** 2), 3, padding=1),
            nn.PixelShuffle(upscale_factor),
            nn.Conv2d(feature_channels, out_channels, 9, padding=4)
        )

                           
        self.residual = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 9, padding=4),
            nn.PReLU(),
            nn.Upsample(scale_factor=upscale_factor, mode='bilinear', align_corners=True)
        )

    def forward(self, x):
                 
        feat1 = self.conv1(x)
        feat2 = self.conv2(x)
        feat3 = self.conv3(x)

              
        fused = self.fusion(torch.cat([feat1, feat2, feat3], dim=1))

               
        att = self.attention(fused)
        enhanced = fused * att

             
        upsampled = self.up(enhanced)

              
        residual = self.residual(x)
        return upsampled + residual


                                                                          
                                                 
class OverlapPatchEmbed(nn.Module):
    def __init__(self, in_c=6, embed_dim=48, bias=False):
        super(OverlapPatchEmbed, self).__init__()

        self.proj = nn.Conv2d(in_c, embed_dim, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, x):
        x = self.proj(x)
        return x


                                                                          
                     
class SAMCE_CR(nn.Module):
                                                     

    def __init__(self,
                 inp_channels=15,
                 out_channels=13,
                 dim=48,
                 num_blocks=[4, 6, 6, 8],
                 num_refinement_blocks=4,
                 heads=[1, 2, 4, 8],
                 ffn_expansion_factor=2.66,
                 bias=False,
                 LayerNorm_type='WithBias',
                 sar_sr_scale=2):
        super().__init__()

                       
        self.sar_sr = SAR_SuperResolution(
            in_channels=2, out_channels=2,
            upscale_factor=sar_sr_scale,
            feature_channels=64
        )
        self.deform_align = DeformableAlign(sar_channels=2, ref_channels=13)

                    
        self.patch_embed = OverlapPatchEmbed(inp_channels, dim)

             
        self.encoder_level1 = nn.Sequential(*[
            TransformerBlock(dim=dim, num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor,
                             bias=bias, LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[0])])

        self.down1_2 = Downsample(dim)
        self.encoder_level2 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[1],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[1])])

                       
        self.down2_3 = Downsample(int(dim * 2 ** 1))
        self.encoder_level3 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 2), num_heads=heads[2],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[2] - 1)])

              
        self.frequency_module = EnhancedFrequencyModule(
            dim=int(dim * 2 ** 2),
            num_heads=heads[2],
            bias=bias
        )

                  
        self.down3_4 = Downsample(int(dim * 2 ** 2))
        self.latent = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 3), num_heads=heads[3],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[3])])

             
        self.up4_3 = Upsample(int(dim * 2 ** 3))
        self.reduce_chan_level3 = nn.Conv2d(int(dim * 2 ** 3), int(dim * 2 ** 2), kernel_size=1, bias=bias)
        self.decoder_level3 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 2), num_heads=heads[2],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[2])])

        self.up3_2 = Upsample(int(dim * 2 ** 2))
        self.reduce_chan_level2 = nn.Conv2d(int(dim * 2 ** 2), int(dim * 2 ** 1), kernel_size=1, bias=bias)
        self.decoder_level2 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[1],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[1])])

        self.up2_1 = Upsample(int(dim * 2 ** 1))
        self.decoder_level1 = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[0],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_blocks[0])])

        self.refinement = nn.Sequential(*[
            TransformerBlock(dim=int(dim * 2 ** 1), num_heads=heads[0],
                             ffn_expansion_factor=ffn_expansion_factor, bias=bias,
                             LayerNorm_type=LayerNorm_type) for _ in range(num_refinement_blocks)])

        self.output = nn.Conv2d(int(dim * 2 ** 1), out_channels=13, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, inp_img, sar):
                     
        sar_sr = self.sar_sr(sar)
        if sar_sr.shape[-2:] != inp_img.shape[-2:]:
            ref_feat = F.adaptive_avg_pool2d(inp_img, sar_sr.shape[-2:])
            sar_sr = self.deform_align(sar_sr, ref_feat)
            sar_sr = F.interpolate(sar_sr, size=inp_img.shape[-2:], mode='bilinear')

              
        inp_cat = torch.cat([inp_img, sar_sr], dim=1)

               
        enc1 = self.patch_embed(inp_cat)
        enc1 = self.encoder_level1(enc1)

        enc2 = self.down1_2(enc1)
        enc2 = self.encoder_level2(enc2)

        enc3 = self.down2_3(enc2)
        enc3 = self.encoder_level3(enc3)

                
        enc3 = self.frequency_module(enc3, enc3)               

        enc4 = self.down3_4(enc3)
        latent = self.latent(enc4)

                     
        dec3 = self.up4_3(latent)
        dec3 = torch.cat([dec3, enc3], 1)
        dec3 = self.reduce_chan_level3(dec3)
        dec3 = self.decoder_level3(dec3)

        dec2 = self.up3_2(dec3)
        dec2 = torch.cat([dec2, enc2], 1)
        dec2 = self.reduce_chan_level2(dec2)
        dec2 = self.decoder_level2(dec2)

        dec1 = self.up2_1(dec2)
        dec1 = torch.cat([dec1, enc1], 1)
        dec1 = self.decoder_level1(dec1)

            
        out = self.refinement(dec1)
        out = self.output(out) + inp_img
        return out