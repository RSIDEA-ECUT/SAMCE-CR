import argparse
import torch
import os
import numpy as np
import random
import torch.nn as nn


def str2bool(v):

    if isinstance(v, bool):
        return v
    if str(v).lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    if str(v).lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    raise argparse.ArgumentTypeError('Boolean value expected.')


class ModelBase(nn.Module):
    def __init__(self):
        super(ModelBase, self).__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def to(self, device=None):
        if device is None:
            device = self.device
        super().to(device)
        self.device = device
        return self

    def save_network(self, network, optimizer, epoch, lr_scheduler, save_dir, best_score=None):
        checkpoint = {
            "network": network.state_dict(),
            'optimizer': optimizer.state_dict(),
            "epoch": epoch,
            "lr_scheduler": lr_scheduler.state_dict()
        }
        if best_score is not None:
            checkpoint['best_psnr'] = best_score
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        save_filename = '%s_net_CR.pth' % (str(epoch))
        save_path = os.path.join(save_dir, save_filename)
        torch.save(checkpoint, save_path)

    def print_networks(self, network):
        print('---------- Networks initialized -------------')
        num_params = 0
        for param in network.parameters():
            num_params += param.numel()
        print('[Network] Total number of parameters : %.3f M' % (num_params / 1e6))
        print('-----------------------------------------------')

    def update_lr(self):
        if hasattr(self, 'lr_scheduler'):
            self.lr_scheduler.step()
            if hasattr(self, 'optimizer_G'):
                for param_group in self.optimizer_G.param_groups:
                    print('optimizer_G_lr', param_group['lr'])

def print_options(opts):
    message = ''
    message += '----------------- Options ---------------\n'
    for k, v in sorted(vars(opts).items()):
        message += '{:>25}: {:<30}\n'.format(str(k), str(v))
    message += '----------------- End -------------------'
    print(message)

    if hasattr(opts, 'save_model_dir'):
        if not os.path.exists(opts.save_model_dir):
            os.makedirs(opts.save_model_dir)
        file_name = os.path.join(opts.save_model_dir, 'opt.txt')
        with open(file_name, 'wt') as opt_file:
            opt_file.write(message)
            opt_file.write('\n')

def seed_torch(seed=7):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True