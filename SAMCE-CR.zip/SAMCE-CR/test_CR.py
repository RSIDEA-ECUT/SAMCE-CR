import os
import torch
import torch.nn as nn
import argparse
from metrics import (PSNR, SSIM, SAM, MAE, LPIPS, FID)
from dataloader import get_filelist, ValDataset, OPT_SCALE
import rasterio


def save_as_tif(pred_data, file_name, results_dir):
    if pred_data.dim() == 4:
        pred_data = pred_data.squeeze(0)
    pred_data = pred_data.cpu().numpy()
    pred_data *= OPT_SCALE
    bands, height, width = pred_data.shape

    out_tif = os.path.join(results_dir, f"{file_name}_pred.tif")

    with rasterio.open(
        out_tif,
        'w',
        driver='GTiff',
        height=height,
        width=width,
        count=bands,
        dtype=pred_data.dtype,

    ) as dst:
        for i in range(bands):
            dst.write(pred_data[i], i + 1)


def to_rgb(images):

    return images[:, :3, ...]


def test(CR_net, opts):
    test_filelist = get_filelist(opts.test_list_filepath)

    test_data = ValDataset(opts, test_filelist)

    test_dataloader = torch.utils.data.DataLoader(dataset=test_data, batch_size=opts.batch_sz, shuffle=False)

    iters = 0
    PSNR_4 = 0
    SSIM_4 = 0
    SAM_4 = 0
    MAE_4 = 0
    LPIPS_4 = 0
    lpips_iters = 0
    fid_metric = None
    try:
        fid_metric = FID(device=next(CR_net.parameters()).device)
    except ImportError as exc:
        print(f'[skip] FID 不可用: {exc}')
    lpips_available = True

    results_dir = "results"
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    with torch.no_grad():
        for inputs in test_dataloader:

            cloudy_data = inputs['cloudy_data'].cuda()
            cloudfree_data = inputs['cloudfree_data'].cuda()
            SAR_data = inputs['SAR_data'].cuda()
            file_name = inputs['file_name'][0]

            pred_cloudfree_data = CR_net(cloudy_data, SAR_data)

            save_as_tif(pred_cloudfree_data, file_name, results_dir)

            results = [file_name]

            psnr_4 = PSNR(pred_cloudfree_data, cloudfree_data)

            ssim_4 = SSIM(pred_cloudfree_data, cloudfree_data)

            pixel_errors = MAE(pred_cloudfree_data, cloudfree_data, False)
            mae_4 = pixel_errors.mean()

            angles = SAM(pred_cloudfree_data, cloudfree_data, False)
            sam_4 = angles.mean()

            if lpips_available:
                try:
                    LPIPS_4 += LPIPS(to_rgb(pred_cloudfree_data.clamp(0, 1)),
                                     to_rgb(cloudfree_data.clamp(0, 1)))
                    lpips_iters += 1
                except ImportError as exc:
                    print(f'[skip] LPIPS 不可用: {exc}')
                    lpips_available = False

            if fid_metric is not None:
                fid_metric.update(to_rgb(cloudfree_data.clamp(0, 1)),
                                  to_rgb(pred_cloudfree_data.clamp(0, 1)))

            PSNR_4 += psnr_4
            SSIM_4 += ssim_4
            SAM_4 += sam_4
            MAE_4 += mae_4
            print(f'{iters}: PSNR:{psnr_4:.4f}, SSIM:{ssim_4:.4f}, SAM:{sam_4:.4f}, MAE:{mae_4:.4f}')

            iters += 1

    print('Testing done. ')
    metrics_log = (f'PSNR:{PSNR_4 / iters:.4f}, SSIM:{SSIM_4 / iters:.4f}, '
                   f'SAM:{SAM_4 / iters:.4f}, MAE:{MAE_4 / iters:.4f}')
    if lpips_iters > 0:
        metrics_log += f', LPIPS:{LPIPS_4 / lpips_iters:.4f}'
    if fid_metric is not None:
        metrics_log += f', FID:{fid_metric.compute():.4f}'
    print(metrics_log)


def main():
    from model_base import str2bool

    parser = argparse.ArgumentParser()
    parser.add_argument('--batch_sz', type=int, default=4, help='batch size used for training')

    parser.add_argument('--input_data_folder', type=str, default='../../LuojiaSET-OSFCR/LuojiaSET-OSFCR')
    parser.add_argument('--test_list_filepath', type=str, default='../../LuojiaSET-OSFCR/LuojiaSET-OSFCR/test.csv')
    parser.add_argument('--checkpoint_path', type=str, default='./checkpoints/best_net_CR.pth')
    parser.add_argument('--is_load_SAR', type=str2bool, default=True)
    parser.add_argument('--is_upsample_SAR', type=str2bool, default=False)
    parser.add_argument('--is_same_resolution', type=str2bool, default=True)
    parser.add_argument('--is_load_cloudmask', type=str2bool, default=False)
    parser.add_argument('--load_size', type=int, default=256)
    parser.add_argument('--crop_size', type=int, default=160)
    parser.add_argument('--model_train_size', type=int, default=-1,
                        help='-1 表示与 crop_size 相同')

    parser.add_argument('--num_opt_channels', type=int, default=13)
    parser.add_argument('--num_sar_channels', type=int, default=2)
    parser.add_argument('--deform_kernel_size', type=int, default=3)

    opts = parser.parse_args()

    if opts.model_train_size < 0:
        opts.model_train_size = opts.crop_size
    if opts.crop_size != opts.model_train_size:
        raise NotImplementedError()

    from net_SAMCE_CR import SAMCE_CR
    CR_net = SAMCE_CR(
        inp_channels=opts.num_opt_channels + opts.num_sar_channels,
        out_channels=opts.num_opt_channels,
        ref_channels=opts.num_opt_channels,
        sar_channels=opts.num_sar_channels,
        deform_kernel_size=opts.deform_kernel_size,
    ).cuda()
    CR_net = nn.DataParallel(CR_net)

    checkpoint = torch.load(opts.checkpoint_path)
    CR_net.load_state_dict(checkpoint['network'])

    CR_net.eval()

    test(CR_net, opts)


if __name__ == "__main__":
    main()



