import os
import argparse
from multiprocessing import freeze_support
import torch
torch.cuda.empty_cache()
if __name__ == '__main__':
    freeze_support()

    from model_base import str2bool

    parser=argparse.ArgumentParser()
    parser.add_argument('--num_workers', default=0, type=int,
                        help='Windows 下建议保持 0，避免 shm.dll 崩溃')
    parser.add_argument('--batch_sz', type=int, default=4, help='batch size used for training')

    parser.add_argument('--input_data_folder', type=str, default='../LuojiaSET-OSFCR/LuojiaSET-OSFCR')
    parser.add_argument('--train_list_filepath', type=str, default='../LuojiaSET-OSFCR/LuojiaSET-OSFCR/train.csv')
    parser.add_argument('--val_list_filepath', type=str, default='../LuojiaSET-OSFCR/LuojiaSET-OSFCR/val.csv')
    parser.add_argument('--is_load_SAR', type=str2bool, default=True)
    parser.add_argument('--is_upsample_SAR', type=str2bool, default=False)
    parser.add_argument('--is_same_resolution', type=str2bool, default=True)
    parser.add_argument('--is_load_cloudmask', type=str2bool, default=True)
    parser.add_argument('--load_size', type=int, default=256)
    parser.add_argument('--crop_size', type=int, default=160)

    parser.add_argument('--num_opt_channels', type=int, default=13)
    parser.add_argument('--num_sar_channels', type=int, default=2)
    parser.add_argument('--deform_kernel_size', type=int, default=3)
    parser.add_argument('--optimizer', type=str, default='Adam', help='Adam')
    parser.add_argument('--lr', type=float, default=1e-4, help='learning rate of optimizer')
    parser.add_argument('--lr_step', type=int, default=5, help='每 lr_step 个 epoch 学习率衰减一半（论文 IV-C：每 5 epoch 衰减 50%%）')
    parser.add_argument('--max_epochs', type=int, default=30)
    parser.add_argument('--save_freq', type=int, default=1)
    parser.add_argument('--val_freq', type=int, default=2)
    parser.add_argument('--log_iter', type=int, default=10)
    parser.add_argument('--auto_resume', type=str2bool, default=True,
                        help='是否自动从 save_model_dir 中最新 checkpoint 续训')
    parser.add_argument('--save_model_dir', type=str, default='./checkpoints', help='directory used to store trained networks')

    parser.add_argument('--gpu_ids', type=str, default='0')


    opts = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = opts.gpu_ids

    from dataloader import get_filelist, TrainDataset, ValDataset
    from model_CR_net import ModelCRNet
    from generic_train import Generic_Train
    from model_base import print_options, seed_torch

    print_options(opts)
    seed_torch()

    train_filelist = get_filelist(opts.train_list_filepath)
    val_filelist = get_filelist(opts.val_list_filepath)

    train_data = TrainDataset(opts, train_filelist)
    val_data = ValDataset(opts, val_filelist)
    print("Train set: %d, Val set: %d" % (len(train_data), len(val_data)))

    train_dataloader = torch.utils.data.DataLoader(dataset=train_data, batch_size=opts.batch_sz,
                                                   shuffle=True, num_workers=opts.num_workers,
                                                   drop_last=True,
                                                   persistent_workers=opts.num_workers > 0)
    val_dataloader = torch.utils.data.DataLoader(dataset=val_data, batch_size=opts.batch_sz,
                                                 shuffle=False, num_workers=opts.num_workers,
                                                 persistent_workers=opts.num_workers > 0)

    model=ModelCRNet(opts)

    Generic_Train(model, opts, train_dataloader, val_dataloader).train()
