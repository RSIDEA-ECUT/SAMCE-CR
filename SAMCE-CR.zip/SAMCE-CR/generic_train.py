import os
import torch


class Generic_Train():
    def __init__(self, model, opts, train_dataloader, val_dataloader):
        self.model = model
        self.opts = opts
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.device = torch.device(f'cuda:{opts.gpu_ids[0]}' if opts.gpu_ids else 'cpu')

        self.start_epoch = 0
        self.total_steps = 0
        self.best_score = 0
        self.log_loss = 0

        if getattr(self.opts, 'auto_resume', True):
            self.load_latest_checkpoint()
        else:
            print("auto_resume disabled: training from scratch")

    def load_latest_checkpoint(self):
        try:
            checkpoint_dir = self.opts.save_model_dir
            if not os.path.exists(checkpoint_dir):
                print(f"Checkpoint directory does not exist: {checkpoint_dir}")
                return

            checkpoint_files = []
            for file in os.listdir(checkpoint_dir):
                if file.endswith('_net_CR.pth'):
                    try:
                        epoch_num = int(file.split('_')[0])
                        checkpoint_files.append((epoch_num, file))
                    except:
                        continue

            if not checkpoint_files:
                print("No checkpoint found, training from scratch")
                return

            latest_epoch, latest_file = max(checkpoint_files, key=lambda x: x[0])
            checkpoint_path = os.path.join(checkpoint_dir, latest_file)

            print(f"Loading latest checkpoint: {checkpoint_path}")
            checkpoint = torch.load(checkpoint_path, map_location=self.device)

            if 'network' in checkpoint:
                self.model.net_G.load_state_dict(checkpoint['network'])
            elif 'model_state_dict' in checkpoint:
                self.model.net_G.load_state_dict(checkpoint['model_state_dict'])

            if 'optimizer' in checkpoint:
                self.model.optimizer_G.load_state_dict(checkpoint['optimizer'])
            elif 'optimizer_state_dict' in checkpoint:
                self.model.optimizer_G.load_state_dict(checkpoint['optimizer_state_dict'])

            if 'lr_scheduler' in checkpoint:
                self.model.lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])

            self.start_epoch = checkpoint.get('epoch', latest_epoch) + 1
            self.best_score = checkpoint.get('best_psnr', 0)

            print(f"Checkpoint loaded successfully!")
            print(f"- Resumed epoch: {self.start_epoch}")
            print(f"- Best PSNR: {self.best_score:.2f}")
            print(f"- Current lr: {self.model.optimizer_G.param_groups[0]['lr']:.2e}")

        except Exception as e:
            print(f"Failed to load checkpoint: {str(e)}")
            print("Training from scratch")

    def train(self):
        total_steps = 0
        log_loss = 0
        best_score = self.best_score

        for epoch in range(self.start_epoch, self.opts.max_epochs):
            for data in self.train_dataloader:
                total_steps += 1

                self.model.set_input(data)
                batch_loss = self.model.optimize_parameters()
                log_loss = log_loss + batch_loss

                if total_steps % self.opts.log_iter == 0:
                    avg_log_loss = log_loss / self.opts.log_iter
                    print('epoch', epoch, 'steps', total_steps, 'loss', avg_log_loss)
                    log_loss = 0

            if (epoch + 1) % self.opts.val_freq == 0:
                print("validation...")
                self.model.net_G.eval()
                with torch.no_grad():
                    _iter = 0
                    score = 0
                    for data in self.val_dataloader:
                        self.model.set_input(data)
                        score += self.model.val_scores()['PSNR']
                        _iter += 1
                    score = score / _iter
                print(f'PSNR: {score}')
                if score > best_score:
                    best_score = score
                    self.model.save_checkpoint('best', best_score=best_score)
                self.model.net_G.train()

            self.model.update_lr()

            if epoch % self.opts.save_freq == 0:
                self.model.save_checkpoint(epoch, best_score=best_score)
