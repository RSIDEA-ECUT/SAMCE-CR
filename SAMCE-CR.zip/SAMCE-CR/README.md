# SAMCE-CR


## 论文信息

- **标题**：SAMCE-CR: SAR-Guided Alignment and Multifrequency Collaborative Enhancement for Cloud Removal in Remote Sensing Images Fusion
- **作者**：Shuting Yang, Xiufang Zhou, Zhenyang Hui, Yichuang Luo, Xunqiang Gong, Lei Zhang, Ailong Ma, Yuting Wan, Yanfei Zhong
- **期刊**：IEEE Transactions on Geoscience and Remote Sensing (TGRS), Vol. 64, 2026
- **DOI**：10.1109/TGRS.2026.3730975
- **官方源码**：https://github.com/RSIDEA-ECUT/SAMCE-CR

## 方法概述

SAMCE-CR 由三个核心模块构成，整体流程为：结构先验提取 → 跨模态几何校正 → 多层特征编码与多频域协同重建 → 渐进式解码与影像生成。

1. **MSPM（Multireceptive Structural Prior Module，多感受野结构先验模块，论文 III-A）**


2. **DCAM（Deformable Cross-modal Alignment Module，可变形跨模态对齐模块，论文 III-B）**


3. **MDSGM（Multifrequency Domain Synergistic Gain Module，多频域协同增益模块，论文 III-C）**



## 环境依赖

- Python 3.8+
- PyTorch 2.0.0+（论文实验环境为 PyTorch 2.0.0 / CUDA 11.8，GPU 为 NVIDIA RTX A5000 16GB）
- 其他依赖：`rasterio`、`numpy`、`torchvision`，以及可选指标所需的 `lpips`、`pytorch-fid`


## 数据集准备

本实现以 **LuojiaSET-OSFCR** 数据集为例（Sentinel-2 13 波段光学 + Sentinel-1 双极化 VV/VH SAR，含云掩膜；共 20000 组，覆盖全球 10 个非重叠区域）。

推荐的目录布局（相对 `SAMCE-CR` 项目根目录）：

```
LuojiaSET-OSFCR/
└── LuojiaSET-OSFCR/
    ├── <cloud-free 光学 tif>
    ├── <cloudy 光学 tif>
    ├── <SAR tif>
    ├── <cloud mask tif>
    ├── train.csv
    ├── val.csv
    └── test.csv
```

`train.csv` / `val.csv` / `test.csv` 每行 5 个字段（逗号分隔），按顺序为：

```
<cloud-free 光学路径>, <cloudy 光学路径>, <SAR 路径>, <保留字段(忽略)>, <云掩膜路径>
```

路径均为相对 `input_data_folder` 的相对路径。

数据归一化规则（见 `dataloader.py`）：
- 光学影像：`x / 10000`（即 `OPT_SCALE`）；
- SAR 影像：按各波段 `clip_min` 裁剪并做 `min-max` 归一化（`SAR_CLIP_MIN`）；
- 云掩膜：归一化到 [0, 1]。

## 训练

默认参数与论文实验设置一致。

```
python train_CR_net.py
```

关键命令行参数（均含合理默认值，可按需覆盖）：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--input_data_folder` | `../LuojiaSET-OSFCR/LuojiaSET-OSFCR` | 数据集根目录 |
| `--train_list_filepath` | `../LuojiaSET-OSFCR/LuojiaSET-OSFCR/train.csv` | 训练列表 |
| `--val_list_filepath` | `../LuojiaSET-OSFCR/LuojiaSET-OSFCR/val.csv` | 验证列表 |
| `--save_model_dir` | `./checkpoints` | 模型保存目录 |
| `--is_load_SAR` | `True` | 是否加载 SAR 辅助数据 |
| `--is_load_cloudmask` | `True` | 是否加载云掩膜 |
| `--is_same_resolution` | `True` | 光学与 SAR 是否同分辨率 |
| `--num_opt_channels` | `13` | 光学波段数（LuojiaSET-OSFCR=13；M3R-CR=4） |
| `--num_sar_channels` | `2` | SAR 波段数 |
| `--batch_sz` | `4` | batch size |
| `--crop_size` | `160` | 裁剪 patch 尺寸 |
| `--load_size` | `256` | 载入影像尺寸（裁剪来源） |
| `--lr` | `1e-4` | 初始学习率 |
| `--lr_step` | `5` | 学习率衰减间隔（epoch） |
| `--max_epochs` | `30` | 最大训练轮数 |
| `--optimizer` | `Adam` | 优化器 |
| `--deform_kernel_size` | `3` | DCAM 可变形卷积核尺寸 |
| `--gpu_ids` | `0` | 使用的 GPU id |
| `--auto_resume` | `True` | 自动从最新 checkpoint 续训 |

训练过程中会按 `save_freq` 保存模型、按 `val_freq` 在验证集上评估并保存最优模型 `best_net_CR.pth`。

## 测试 / 评估

加载训练得到的最优权重，在测试集上计算各项指标并（可选）输出预测影像。

```
python test_CR.py --checkpoint_path ./checkpoints/best_net_CR.pth
```

主要参数：`--test_list_filepath`（默认 `../../LuojiaSET-OSFCR/LuojiaSET-OSFCR/test.csv`）、`--input_data_folder`、`--is_load_SAR`、`--num_opt_channels`、`--num_sar_channels`、`--crop_size`、`--load_size`。

输出的指标包括 PSNR / SSIM / SAM / MAE（始终计算），以及 LPIPS / FID（若已安装 `lpips` / `pytorch-fid` 则自动计算，否则跳过）。

## 评估指标（论文 IV-D）

| 指标 | 含义 |
|------|------|
| PSNR | 峰值信噪比，衡量像素级统计误差 |
| MAE | 平均绝对误差，衡量像素级误差 |
| SSIM | 结构相似性，衡量空间拓扑结构保真度 |
| SAM | 光谱角映射，衡量光谱信息保真度 |
| LPIPS | 学习感知图像块相似度，衡量生成影像的真实感 |
| FID | Fréchet Inception Distance，衡量生成影像分布真实性 |

## 项目结构

```
SAMCE-CR/
├── net_SAMCE_CR.py        # 模型定义（SAMCE_CR 及 MSPM/DCAM/MDSGM 等子模块）
├── model_CR_net.py        # 训练封装（ModelCRNet：前向、损失、优化步骤）
├── losses.py              # ECCharbonnierLoss（Charbonnier + 云区约束）
├── metrics.py             # PSNR / SSIM / SAM / MAE / LPIPS / FID
├── dataloader.py          # 数据读取与归一化（TrainDataset / ValDataset）
├── model_base.py          # 模型基类（ModelBase）
├── generic_train.py       # 通用训练循环（Generic_Train）
├── train_CR_net.py        # 训练入口
├── test_CR.py             # 评估入口
├── checkpoints/           # 训练产出的模型权重
└── results/               # 预测结果输出目录
```

## 引用

如果本实现对你的研究有帮助，请引用原论文：

```bibtex
@article{yang2026samce,
  title={SAMCE-CR: SAR-Guided Alignment and Multifrequency Collaborative Enhancement for Cloud Removal in Remote Sensing Images Fusion},
  author={Yang, Shuting and Zhou, Xiufang and Hui, Zhenyang and Luo, Yichuang and Gong, Xunqiang and Zhang, Lei and Ma, Ailong and Wan, Yuting and Zhong, Yanfei},
  journal={IEEE Transactions on Geoscience and Remote Sensing},
  volume={64},
  year={2026},
  doi={10.1109/TGRS.2026.3730975}
}
```

## 许可

本仓库为论文方法的复现实现，仅供研究学习使用。原论文版权归作者及 IEEE 所有，数据集使用请遵循相应数据集的许可协议。
