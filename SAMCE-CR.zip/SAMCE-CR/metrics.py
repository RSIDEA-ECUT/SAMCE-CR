import math
import torch
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
from math import exp

def gaussian(window_size, sigma):
    gauss = torch.Tensor([exp(-(x - window_size / 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)])
    return gauss / gauss.sum()

def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = Variable(_2D_window.expand(channel, 1, window_size, window_size))
    return window

def SSIM(img1, img2):
    (_, channel, _, _) = img1.size()
    window_size = 11
    window = create_window(window_size, channel).cuda()
    mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
    mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2

    sigma1_sq = F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel) - mu1_mu2

    C1 = 0.01 ** 2
    C2 = 0.03 ** 2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
    return ssim_map.mean().item()

def PSNR(img1, img2, mask=None):
    if mask is not None:
        mse = (img1 - img2) ** 2
        B, C, H, W = mse.size()
        mse = torch.sum(mse * mask.float()) / (torch.sum(mask.float()) * C)
    else:
        mse = torch.mean((img1 - img2) ** 2)

    if mse == 0:
        return 100
    PIXEL_MAX = 1
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))

def MAE(ref, tgt, is_mean = True):
    ref = ref.cpu().detach().numpy()
    tgt = tgt.cpu().detach().numpy()
    pixel_errors = np.absolute(ref - tgt)
    if is_mean:
        return pixel_errors.mean()
    else:
        return pixel_errors

def SAM(ref, tgt, is_mean = True):

    ref = ref.cpu().detach().numpy()
    tgt = tgt.cpu().detach().numpy()

    ref = ref.transpose(0, 2, 3, 1)
    tgt = tgt.transpose(0, 2, 3, 1)

    kernel = np.einsum('...k,...k', ref, tgt)

    square_norm_ref = np.einsum('...k,...k', ref, ref).clip(min=np.finfo(np.float16).eps)
    square_norm_tgt = np.einsum('...k,...k', tgt, tgt).clip(min=np.finfo(np.float16).eps)
    normalized_kernel = kernel / np.sqrt(square_norm_ref * square_norm_tgt)

    angles = np.arccos(normalized_kernel.clip(min=-1, max=1)) / np.pi * 180

    if is_mean:
        return angles.mean()
    else:
        return angles

_LPIPS_FN = None


def _get_lpips(device):
    global _LPIPS_FN
    if _LPIPS_FN is None:
        try:
            import lpips
        except ImportError as exc:
            raise ImportError(
                'LPIPS 指标需要 `lpips` 包与预训练权重：pip install lpips'
            ) from exc
        _LPIPS_FN = lpips.LPIPS(net='alex').to(device).eval()
    return _LPIPS_FN


def LPIPS(img1, img2):
    fn = _get_lpips(img1.device)
    with torch.no_grad():
        dist = fn(img1.clamp(0, 1) * 2 - 1, img2.clamp(0, 1) * 2 - 1)
    return dist.mean().item()


class FID(object):
    def __init__(self, device=None):
        try:
            from pytorch_fid.inception import InceptionV3
        except ImportError as exc:
            raise ImportError(
                'FID 指标需要 `pytorch-fid` 包：pip install pytorch-fid'
            ) from exc

        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.device = device
        block_idx = InceptionV3.BLOCK_INDEX_BY_DIM[2048]
        self.model = InceptionV3([block_idx]).to(device).eval()
        self.real_feats = []
        self.fake_feats = []

    def _features(self, images):
        if images.shape[1] != 3:
            raise ValueError(
                'FID/LPIPS 需要 3 通道输入，当前为 %d 通道；'
                '请先构造 RGB 合成影像。' % images.shape[1]
            )
        with torch.no_grad():
            feats = self.model(images.to(self.device))[0]
        return feats.squeeze(-1).squeeze(-1).cpu().numpy()

    def update(self, real, fake):
        self.real_feats.append(self._features(real))
        self.fake_feats.append(self._features(fake))

    def compute(self):
        from pytorch_fid.fid_score import calculate_frechet_distance

        act_real = np.concatenate(self.real_feats, axis=0)
        act_fake = np.concatenate(self.fake_feats, axis=0)
        mu_real, sigma_real = act_real.mean(0), np.cov(act_real, rowvar=False)
        mu_fake, sigma_fake = act_fake.mean(0), np.cov(act_fake, rowvar=False)
        return float(calculate_frechet_distance(mu_real, sigma_real, mu_fake, sigma_fake))
