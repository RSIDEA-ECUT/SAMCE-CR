import os
import csv
import rasterio
import numpy as np
import random
import argparse

import torch
from torch.utils.data import Dataset


def get_filelist(listpath):
    filelist = []
    list_csv_file = open(listpath, "r")
    list_reader = csv.reader(list_csv_file)
    for item in list_reader:
        filelist.append(item)
    list_csv_file.close()
    return filelist


def get_opt_image(path):
    src = rasterio.open(path, 'r', driver='GTiff')
    image = src.read()
    src.close()
    image[np.isnan(image)] = np.nanmean(image)
    return image.astype('float32')


def get_sar_image(path, load_size, is_upsample_SAR):
    src = rasterio.open(path, 'r', driver='GTiff')
    if is_upsample_SAR:
        image = src.read(out_shape=(src.count, load_size, load_size), resampling=rasterio.enums.Resampling.nearest)
    else:
        image = src.read()
    src.close()
    image[np.isnan(image)] = np.nanmean(image)
    return image.astype('float32')


SAR_CLIP_MIN = [-25.0, -32.5]
OPT_SCALE = 10000


def get_cloudmask_image(path):
    with rasterio.open(path) as src:
        cm_data = src.read(1).astype('float32')
    cm_data[np.isnan(cm_data)] = 0.0
    cm_data[cm_data < 0] = 0.0
    max_value = float(cm_data.max()) if cm_data.size > 0 else 0.0
    if max_value > 1.0:
        cm_data = cm_data / max_value
    return np.clip(cm_data, 0.0, 1.0).astype('float32')


def get_normalized_data(data_image, data_type, num_opt_channels=13, num_sar_channels=2):
    clip_min = {1: SAR_CLIP_MIN[:num_sar_channels],
                2: [0] * num_opt_channels,
                3: [0] * num_opt_channels}
    clip_max = {1: [0] * num_sar_channels,
                2: [OPT_SCALE] * num_opt_channels,
                3: [OPT_SCALE] * num_opt_channels}

    if data_type not in [1, 2, 3]:
        raise ValueError("data_type must be 1 (SAR), 2 (cloud-free OPT), or 3 (cloudy OPT)")

    n_channels = data_image.shape[0]
    expected_channels = {1: num_sar_channels, 2: num_opt_channels, 3: num_opt_channels}
    if n_channels != expected_channels[data_type]:
        raise ValueError(f"Expected {expected_channels[data_type]} channels, got {n_channels}")

    scale = OPT_SCALE
    for channel in range(n_channels):
        data_image[channel] = np.clip(
            data_image[channel],
            clip_min[data_type][channel],
            clip_max[data_type][channel]
        )
        if data_type == 1:
            data_image[channel] -= clip_min[data_type][channel]
            data_image[channel] /= (clip_max[data_type][channel] - clip_min[data_type][channel])
        else:
            data_image[channel] /= scale

    return data_image


class TrainDataset(Dataset):
    def __init__(self, opts, filelist):
        self.input_data_folder = opts.input_data_folder
        self.is_load_SAR = opts.is_load_SAR
        self.is_upsample_SAR = opts.is_upsample_SAR
        self.is_load_cloudmask = opts.is_load_cloudmask
        self.is_same_resolution = getattr(opts, 'is_same_resolution', False)
        self.load_size = opts.load_size
        self.crop_size = opts.crop_size
        self.num_opt_channels = getattr(opts, 'num_opt_channels', 13)
        self.num_sar_channels = getattr(opts, 'num_sar_channels', 2)

        if (not self.is_same_resolution) and (self.is_load_SAR and not self.is_upsample_SAR):
            self.crop_size_10m = self.crop_size * 3 / 10
            assert self.crop_size_10m.is_integer()
            self.crop_size_10m = int(self.crop_size_10m)

        self.filelist = filelist
        self.n_images = len(self.filelist)

    def __getitem__(self, index):
        [planet_cloudfree_path, planet_cloudy_path, S1_path, _, cloudmask_path] = self.filelist[index]

        planet_cloudfree_path = os.path.join(self.input_data_folder, planet_cloudfree_path)
        planet_cloudy_path = os.path.join(self.input_data_folder, planet_cloudy_path)
        if self.is_load_SAR:
            s1_path = os.path.join(self.input_data_folder, S1_path)
        if self.is_load_cloudmask:
            cm_path = os.path.join(self.input_data_folder, cloudmask_path)

        planet_cloudfree_data = get_opt_image(planet_cloudfree_path)
        planet_cloudy_data = get_opt_image(planet_cloudy_path)
        if self.is_load_SAR:
            s1_data = get_sar_image(s1_path, self.load_size, self.is_upsample_SAR)
        if self.is_load_cloudmask:
            cm_data = get_cloudmask_image(cm_path)

        planet_cloudfree_data = get_normalized_data(planet_cloudfree_data, data_type=2,
                                                    num_opt_channels=self.num_opt_channels,
                                                    num_sar_channels=self.num_sar_channels)
        planet_cloudy_data = get_normalized_data(planet_cloudy_data, data_type=3,
                                                 num_opt_channels=self.num_opt_channels,
                                                 num_sar_channels=self.num_sar_channels)
        if self.is_load_SAR:
            s1_data = get_normalized_data(s1_data, data_type=1,
                                          num_opt_channels=self.num_opt_channels,
                                          num_sar_channels=self.num_sar_channels)

        planet_cloudfree_data = torch.from_numpy(planet_cloudfree_data)
        planet_cloudy_data = torch.from_numpy(planet_cloudy_data)
        if self.is_load_SAR:
            s1_data = torch.from_numpy(s1_data)
        if self.is_load_cloudmask:
            cm_data = torch.from_numpy(cm_data)

        if self.load_size - self.crop_size > 0:
            if (not self.is_same_resolution) and (self.is_load_SAR and not self.is_upsample_SAR):
                y = random.randint(0, np.maximum(0, (self.load_size - self.crop_size) // 10))
                x = random.randint(0, np.maximum(0, (self.load_size - self.crop_size) // 10))
                y_3m, x_3m, y_10m, x_10m = y * 10, x * 10, y * 3, x * 3
                if self.is_load_SAR:
                    if self.is_upsample_SAR:
                        s1_data = s1_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
                    else:
                        s1_data = s1_data[..., y_10m:y_10m + self.crop_size_10m, x_10m:x_10m + self.crop_size_10m]
            else:
                y = random.randint(0, np.maximum(0, self.load_size - self.crop_size))
                x = random.randint(0, np.maximum(0, self.load_size - self.crop_size))
                y_3m, x_3m = y, x
                if self.is_load_SAR:
                    s1_data = s1_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]

            planet_cloudfree_data = planet_cloudfree_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
            planet_cloudy_data = planet_cloudy_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
            if self.is_load_cloudmask:
                cm_data = cm_data[y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]

        results = {'cloudy_data': planet_cloudy_data,
                   'cloudfree_data': planet_cloudfree_data,
                   'file_name': os.path.basename(planet_cloudfree_path)}
        if self.is_load_SAR:
            results['SAR_data'] = s1_data
        if self.is_load_cloudmask:
            results['cloudmask_data'] = cm_data

        return results

    def __len__(self):
        return self.n_images


class ValDataset(Dataset):
    def __init__(self, opts, filelist):
        self.input_data_folder = opts.input_data_folder
        self.is_load_SAR = opts.is_load_SAR
        self.is_upsample_SAR = opts.is_upsample_SAR
        self.is_load_cloudmask = opts.is_load_cloudmask
        self.is_same_resolution = getattr(opts, 'is_same_resolution', False)
        self.load_size = opts.load_size
        self.crop_size = opts.crop_size
        self.num_opt_channels = getattr(opts, 'num_opt_channels', 13)
        self.num_sar_channels = getattr(opts, 'num_sar_channels', 2)

        if (not self.is_same_resolution) and (self.is_load_SAR and not self.is_upsample_SAR):
            self.crop_size_10m = self.crop_size * 3 / 10
            assert self.crop_size_10m.is_integer()
            self.crop_size_10m = int(self.crop_size_10m)

        self.filelist = filelist
        self.n_images = len(self.filelist)

    def __getitem__(self, index):
        [planet_cloudfree_path, planet_cloudy_path, S1_path, _, cloudmask_path] = self.filelist[index]

        planet_cloudfree_path = os.path.join(self.input_data_folder, planet_cloudfree_path)
        planet_cloudy_path = os.path.join(self.input_data_folder, planet_cloudy_path)
        if self.is_load_SAR:
            s1_path = os.path.join(self.input_data_folder, S1_path)
        if self.is_load_cloudmask:
            cm_path = os.path.join(self.input_data_folder, cloudmask_path)

        planet_cloudfree_data = get_opt_image(planet_cloudfree_path)
        planet_cloudy_data = get_opt_image(planet_cloudy_path)
        if self.is_load_SAR:
            s1_data = get_sar_image(s1_path, self.load_size, self.is_upsample_SAR)
        if self.is_load_cloudmask:
            cm_data = get_cloudmask_image(cm_path)

        planet_cloudfree_data = get_normalized_data(planet_cloudfree_data, data_type=2,
                                                    num_opt_channels=self.num_opt_channels,
                                                    num_sar_channels=self.num_sar_channels)
        planet_cloudy_data = get_normalized_data(planet_cloudy_data, data_type=3,
                                                 num_opt_channels=self.num_opt_channels,
                                                 num_sar_channels=self.num_sar_channels)
        if self.is_load_SAR:
            s1_data = get_normalized_data(s1_data, data_type=1,
                                          num_opt_channels=self.num_opt_channels,
                                          num_sar_channels=self.num_sar_channels)

        planet_cloudfree_data = torch.from_numpy(planet_cloudfree_data)
        planet_cloudy_data = torch.from_numpy(planet_cloudy_data)
        if self.is_load_SAR:
            s1_data = torch.from_numpy(s1_data)
        if self.is_load_cloudmask:
            cm_data = torch.from_numpy(cm_data)

        if self.load_size - self.crop_size > 0:
            if (not self.is_same_resolution) and (self.is_load_SAR and not self.is_upsample_SAR):
                y = np.maximum(0, (self.load_size - self.crop_size) // 10) // 2
                x = np.maximum(0, (self.load_size - self.crop_size) // 10) // 2
                y_3m, x_3m, y_10m, x_10m = y * 10, x * 10, y * 3, x * 3
                if self.is_load_SAR:
                    if self.is_upsample_SAR:
                        s1_data = s1_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
                    else:
                        s1_data = s1_data[..., y_10m:y_10m + self.crop_size_10m, x_10m:x_10m + self.crop_size_10m]
            else:
                y = np.maximum(0, self.load_size - self.crop_size) // 2
                x = np.maximum(0, self.load_size - self.crop_size) // 2
                y_3m, x_3m = y, x
                if self.is_load_SAR:
                    s1_data = s1_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]

            planet_cloudfree_data = planet_cloudfree_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
            planet_cloudy_data = planet_cloudy_data[..., y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]
            if self.is_load_cloudmask:
                cm_data = cm_data[y_3m:y_3m + self.crop_size, x_3m:x_3m + self.crop_size]

        results = {'cloudy_data': planet_cloudy_data,
                   'cloudfree_data': planet_cloudfree_data,
                   'file_name': os.path.basename(planet_cloudfree_path)}
        if self.is_load_SAR:
            results['SAR_data'] = s1_data
        if self.is_load_cloudmask:
            results['cloudmask_data'] = cm_data

        return results

    def __len__(self):
        return self.n_images


if __name__ == "__main__":
    from model_base import str2bool

    parser = argparse.ArgumentParser()
    parser.add_argument('--load_size', type=int, default=256)
    parser.add_argument('--crop_size', type=int, default=160)
    parser.add_argument('--input_data_folder', type=str, default='../../LuojiaSET-OSFCR/LuojiaSET-OSFCR')
    parser.add_argument('--is_load_SAR', type=str2bool, default=True)
    parser.add_argument('--is_upsample_SAR', type=str2bool, default=False)
    parser.add_argument('--is_same_resolution', type=str2bool, default=True)
    parser.add_argument('--is_load_cloudmask', type=str2bool, default=True)
    parser.add_argument('--num_opt_channels', type=int, default=13)
    parser.add_argument('--num_sar_channels', type=int, default=2)
    parser.add_argument('--data_list_filepath', type=str, default=r'E:\YST\Luojia\LuojiaSET-OSFCR\LuojiaSET-OSFCR\train.csv')

    opts = parser.parse_args()

    train_filelist = get_filelist(opts.data_list_filepath)
    data = TrainDataset(opts, train_filelist)
    dataloader = torch.utils.data.DataLoader(dataset=data, batch_size=1, shuffle=True)

    _iter = 0
    for results in dataloader:
        cloudy_data = results['cloudy_data']
        cloudfree_data = results['cloudfree_data']
        file_name = results['file_name'][0]
        print(file_name)
        print('cloudy_data:', cloudy_data.shape)
        print('cloudfree_data', cloudfree_data.shape)

        if opts.is_load_SAR:
            s1_data = results['SAR_data']
            print('SAR_data:', s1_data.shape)
        if opts.is_load_cloudmask:
            cm_data = results['cloudmask_data']
            print('cloudmask_data:', cm_data.shape)

        _iter += 1
        input()
